package chapter8;

public class RunnableSample {
	
	public static void main(String[] args) throws Exception {
		// �������߳�
		Thread t = new Thread(new RunnableTest());
		t.start();
		
		while (true) {
			System.out.println("����main()����");
			// �߳�����
			Thread.sleep(100);
		}
	}
}

class RunnableTest implements Runnable {

    @Override
    public void run() {
    	while (true) {
			System.out.println("����run()����");
			try {
	            Thread.sleep(100);
            } catch (InterruptedException e) {
	            e.printStackTrace();
            }
		}
    }
}