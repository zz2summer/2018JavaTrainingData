package chapter8;

public class Exercise {
	public static int num = 1;
	public static void main(String[] args) throws InterruptedException {
		new ExerciseThread().start();
		while (num <= 20) {
			System.out.println("���߳������ " + num++);
			Thread.sleep(10);
		}
	}
}

class ExerciseThread extends Thread {
	@Override
	public void run() {
	    while (Exercise.num <= 20) {
	    	System.out.println("���߳������ " + Exercise.num++);
	    	try {
	            Thread.sleep(10);
            } catch (InterruptedException e) {
	            e.printStackTrace();
            }
	    }
	}
}